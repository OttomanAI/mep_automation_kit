"""
LandXML to Revit CSV Converter
================================
Converts a Civil 3D LandXML pipe network export into a CSV file
with pre-computed Revit internal coordinates for use with Dynamo.

USAGE:
    1. Export your pipe network from Civil 3D as LandXML (.xml)
    2. Run this script:
       python landxml_to_revit_csv.py

    The script will ask you to drag-and-drop or type the path to your XML file.
    It outputs a CSV file in the same folder, ready for the Dynamo script.

CALIBRATION:
    The transform values below are calibrated for the HEL11 project.
    If you use this on a different project, you'll need to recalibrate
    the PBP_E, PBP_N, PBP_Z, ATN, Px, Py, Pz values.
    See the RECALIBRATION section at the bottom of this file for instructions.
"""

import xml.etree.ElementTree as ET
import csv
import math
import os
import sys


# ============================================================
# PROJECT CALIBRATION VALUES - HEL11 Battery Room
# ============================================================
# Project Base Point shared coordinates (meters, from Revit)
PBP_E = 24517724.1561   # E/W (Easting)
PBP_N = 6687664.9191    # N/S (Northing)
PBP_Z = 76.750          # Elevation

# Angle to True North (degrees, from Revit Project Base Point)
ATN = 124.703

# Internal origin offset of PBP (mm, calibrated from known points)
Px = -150411.3
Py = 361179.6
Pz = -14117.0
# ============================================================


def parse_landxml(xml_path):
    """Parse a LandXML file and extract structures and pipes."""
    tree = ET.parse(xml_path)
    root = tree.getroot()

    # Auto-detect namespace
    ns_uri = ''
    tag = root.tag
    if '{' in tag:
        ns_uri = tag.split('}')[0] + '}'
    ns = {'lx': ns_uri.strip('{}')} if ns_uri else {}

    def find(element, path):
        if ns:
            return element.findall(path.replace('/', '/lx:').replace('/lx:/', '/'), ns)
        return element.findall(path)

    def find_one(element, path):
        results = find(element, path)
        return results[0] if results else None

    # Parse structures (manholes, endpoints)
    structs = {}
    for s in root.iter():
        if s.tag.endswith('Struct'):
            name = s.get('name', '')
            center = None
            for child in s:
                if child.tag.endswith('Center') and child.text:
                    center = child
                    break
            if center is None:
                continue

            parts = center.text.strip().split()
            northing = float(parts[0])
            easting = float(parts[1])

            inverts = [child for child in s if child.tag.endswith('Invert')]
            inv_elevs = [float(iv.get('elev', '0')) for iv in inverts]
            avg_inv = sum(inv_elevs) / len(inv_elevs) if inv_elevs else 0

            structs[name] = {
                'easting': easting,
                'northing': northing,
                'invert_elev': avg_inv,
                'is_null': 'Null' in name
            }

    # Parse pipes
    pipes = []
    for p in root.iter():
        if p.tag.endswith('Pipe') and p.get('refStart'):
            name = p.get('name', '')
            ref_start = p.get('refStart', '')
            ref_end = p.get('refEnd', '')
            desc = p.get('desc', '')
            length = p.get('length', '0')
            slope = p.get('slope', '0')

            # Find CircPipe for diameter
            circ = None
            for child in p:
                if child.tag.endswith('CircPipe'):
                    circ = child
                    break

            diameter = float(circ.get('diameter', '0')) if circ is not None else 0
            material = circ.get('material', '') if circ is not None else ''

            if ref_start in structs and ref_end in structs:
                pipes.append({
                    'name': name,
                    'start_struct': ref_start,
                    'end_struct': ref_end,
                    'diameter': diameter,
                    'material': material,
                    'description': desc,
                    'length': length,
                    'slope': slope,
                    'start': structs[ref_start],
                    'end': structs[ref_end]
                })

    return structs, pipes


def shared_to_internal(easting, northing, elevation):
    """
    Transform OSGB shared coordinates to Revit internal coordinates.

    Steps:
        1. Subtract Project Base Point shared coords to get delta in meters
        2. Rotate by Angle to True North
        3. Convert to mm
        4. Add internal PBP offset (Px, Py, Pz)
    """
    atn_rad = ATN * math.pi / 180
    cos_a = math.cos(atn_rad)
    sin_a = math.sin(atn_rad)

    dE = easting - PBP_E    # meters
    dN = northing - PBP_N   # meters
    dZ = elevation - PBP_Z  # meters

    x = Px + (dE * cos_a - dN * sin_a) * 1000  # mm
    y = Py + (dE * sin_a + dN * cos_a) * 1000  # mm
    z = Pz + dZ * 1000                          # mm

    return round(x, 1), round(y, 1), round(z, 1)


def convert(xml_path, output_path=None):
    """Convert a LandXML file to a Dynamo-ready CSV."""

    print(f"\nParsing: {xml_path}")
    structs, pipes = parse_landxml(xml_path)

    print(f"  Found {len(structs)} structures, {len(pipes)} pipes")

    # Count types
    real = sum(1 for s in structs.values() if not s['is_null'])
    null = sum(1 for s in structs.values() if s['is_null'])
    diameters = sorted(set(p['diameter'] for p in pipes))
    materials = sorted(set(p['material'] for p in pipes if p['material']))

    print(f"  Structures: {real} real manholes, {null} null endpoints")
    print(f"  Pipe diameters: {diameters} mm")
    print(f"  Materials: {materials}")

    # Transform and write CSV
    rows = []
    for p in pipes:
        sx, sy, sz = shared_to_internal(
            p['start']['easting'],
            p['start']['northing'],
            p['start']['invert_elev']
        )
        ex, ey, ez = shared_to_internal(
            p['end']['easting'],
            p['end']['northing'],
            p['end']['invert_elev']
        )
        rows.append([sx, sy, sz, ex, ey, ez, p['diameter']])

    if output_path is None:
        base = os.path.splitext(xml_path)[0]
        output_path = base + '_revit_coords.csv'

    with open(output_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['SX', 'SY', 'SZ', 'EX', 'EY', 'EZ', 'Dia'])
        writer.writerows(rows)

    # Print summary
    all_z = [r[2] for r in rows] + [r[5] for r in rows]
    print(f"\n  Output: {output_path}")
    print(f"  Pipes written: {len(rows)}")
    print(f"  Z range: {min(all_z):.0f} to {max(all_z):.0f} mm "
          f"(span: {(max(all_z) - min(all_z)) / 1000:.1f}m)")
    print(f"\n  Ready for Dynamo!")

    return output_path


# ============================================================
# MAIN
# ============================================================
if __name__ == '__main__':

    if len(sys.argv) > 1:
        xml_path = sys.argv[1].strip().strip('"').strip("'")
    else:
        print("=" * 60)
        print("  LandXML to Revit CSV Converter")
        print("  Calibrated for: HEL11 Project")
        print("=" * 60)
        xml_path = input("\nDrag and drop your XML file here (or type the path):\n> ")
        xml_path = xml_path.strip().strip('"').strip("'")

    if not os.path.exists(xml_path):
        print(f"\nERROR: File not found: {xml_path}")
        input("\nPress Enter to exit...")
        sys.exit(1)

    try:
        output = convert(xml_path)
        print(f"\nDone! Place '{os.path.basename(output)}' in the same folder as your .dyn file.")
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()

    input("\nPress Enter to exit...")


# ============================================================
# RECALIBRATION GUIDE (for use on a different project)
# ============================================================
#
# If you need to use this script on a different Revit project,
# you'll need to update the calibration values at the top:
#
# 1. PBP_E, PBP_N, PBP_Z:
#    From Revit, click on the Project Base Point and read
#    the E/W, N/S, and Elev values (convert from mm to meters
#    by dividing by 1000).
#
# 2. ATN:
#    From the Project Base Point properties, read
#    "Angle to True North" in degrees.
#
# 3. Px, Py, Pz (internal origin offset):
#    This accounts for the PBP not being at Revit's internal origin.
#    To find these values:
#
#    a) Place a test pipe using the script with Px=0, Py=0, Pz=0
#    b) Use Spot Coordinate tool on a point in the placed pipe
#       to read its shared coordinates (E_shown, N_shown, Z_shown)
#    c) You know the correct shared coords from the XML (E_xml, N_xml, Z_xml)
#    d) Run this calculation:
#
#       atn_rad = ATN * pi / 180
#       cos_a = cos(atn_rad)
#       sin_a = sin(atn_rad)
#
#       # What you computed for that point with Px=Py=Pz=0:
#       x_test = (E_xml - PBP_E) * cos_a - (N_xml - PBP_N) * sin_a) * 1000
#       y_test = (E_xml - PBP_E) * sin_a + (N_xml - PBP_N) * cos_a) * 1000
#       z_test = (Z_xml - PBP_Z) * 1000
#
#       # From spot coordinate readout:
#       dE_shown = (E_shown - PBP_E) * 1000
#       dN_shown = (N_shown - PBP_N) * 1000
#       a = dE_shown * cos_a - dN_shown * sin_a
#       b = dE_shown * sin_a + dN_shown * cos_a
#
#       Px = x_test - a
#       Py = y_test - b
#       Pz = z_test - (Z_shown - PBP_Z) * 1000
#
